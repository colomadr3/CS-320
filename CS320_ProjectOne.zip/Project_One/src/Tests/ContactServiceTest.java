package Tests;

import java.util.HashMap;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Project.contactService.Contact;
import Project.contactService.ContactService;

public class ContactServiceTest {
	//Create a new hash map
	HashMap<String, Contact> contactMap = new HashMap<String,Contact>();

	@Test
	//Test AddContact Method
	void ContactServiceAddTest() {
		//Create a new Contact object
		Contact contactObj = new Contact("Raph", "Coloma", "123456789", "Las Vegas", "5555551234");
		//Method call to add contact to hash map
		ContactService.AddContact(contactMap, contactObj);
		//Assertion to check Contact object variables in hash map
	    assertAll("Add",()-> assertEquals("Raph",contactMap.get("123456789").firstName),
	            		()-> assertEquals("Coloma",contactMap.get("123456789").lastName),
	            		()-> assertEquals("Las Vegas",contactMap.get("123456789").contactAddy),
	            		()-> assertEquals("5555551234",contactMap.get("123456789").phoneNum));
	}
	
	@Test
	//Test RemoveContact Method
	void ContactServiceRemoveTest() {
		//Create new Contact objects
		Contact contactObj = new Contact("Raph", "Coloma", "234567891", "Las Vegas", "5555551234");
		Contact contactObj2 = new Contact("John", "Smith", "987654321", "Marlia St.", "5555555555");
		//Method call to add contacts to hash map
		ContactService.AddContact(contactMap, contactObj);
		ContactService.AddContact(contactMap, contactObj2);	
		//Method call to remove contact from hash map
		ContactService.RemoveContact(contactMap, "987654321");
		//Assersion to check that Contact was removed
		assertAll("Remove",()-> assertEquals(null,contactMap.get("987654321")));

	}
	
	@Test
	//Test methods that update Contact object variables in hash map
	void ContactServiceUpdateTest() {
		//Create new Contact objects
		Contact contactObj = new Contact("Raph", "Coloma", "345678912", "Las Vegas", "5555551234");
		//Method call to add contacts to hash map
		ContactService.AddContact(contactMap, contactObj);
		//Method calls to updated Contact object variables in hash map
		ContactService.UpdateFName(contactMap, "345678912", "Michael");
		ContactService.UpdateLName(contactMap, "345678912", "Jordan");
		ContactService.UpdateAddy(contactMap, "345678912", "Chicago");
		ContactService.UpdateNumber(contactMap, "345678912", "5555554321");
		//Assersion to check that Contact object variables were updated
		assertAll("Update",()-> assertEquals("Michael",contactMap.get("345678912").firstName),
	            		   ()-> assertEquals("Jordan",contactMap.get("345678912").lastName),
	            		   ()-> assertEquals("Chicago",contactMap.get("345678912").contactAddy),
	            		   ()-> assertEquals("5555554321",contactMap.get("345678912").phoneNum));

	}
	@Test
	void testContactServiceSameID() {
		//Create new Contact objects
		Contact contactObj = new Contact("Raph", "Coloma", "11111", "Las Vegas", "5555551234");
		Contact contactObj2 = new Contact("John", "Smith", "11111", "Marlia St.", "5555555555");
		
		//Method call to add contacts to hash map
		ContactService.AddContact(contactMap, contactObj);
		//Expect Exception from duplicate IDs
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			ContactService.AddContact(contactMap, contactObj2);
			});
	}
}
