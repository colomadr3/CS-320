package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Project.contactService.Contact;

public class ContactTest {
	
	@Test
	//Tests to check Exception Throws for Contact object variable - Exceptions expected
	void testContactClassFName() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("RianColoma21", "Coloma", "98765431", "Marlia St.", "5555553110");
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact(null, "Coloma", "98765431", "Marlia St.", "5555553110");
			});
	}
	
	@Test
	void testContactClassLName() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("Rian", "RianColoma21", "98765431", "Marlia St.", "5555553110");
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("Rian", null, "98765431", "Marlia St.", "5555553110");
			});
	}
	
	@Test
	void testContactClassID() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("Rian", "Coloma", "11098765431", "Marlia St.", "5555553110");
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("Rian", "Coloma", null, "Marlia St.", "5555553110");
			});
	}
	
	@Test
	void testContactClassAddress() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("Rian", "Coloma", "98765431", "United States of America on the corner of fifteenth and eighth.", "5555553110");
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("Rian", "Coloma", "98765431", null, "5555553110");
			});
	}
	
	@Test
	void testContactClassPhone() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("Rian", "Coloma", "98765431", "Marlia St.", "5553110");
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("Rian", "Coloma", "98765431", "Marlia St.", null);
			});
	}
	
	@Test
	//Test Contact object Constructor
	void testContact() {
		//Create new Contact object
		Contact contactClass = new Contact("Rian", "Coloma", "123456789", "Marlia St.", "5555553110");
		//Assertions to check Contact object variable
		assertTrue(contactClass.getFirstName().equals("Rian"));
		assertTrue(contactClass.getLastName().equals("Coloma"));
		assertTrue(contactClass.getContactID().equals("123456789"));
		assertTrue(contactClass.getContactAddy().equals("Marlia St."));
		assertTrue(contactClass.getPhoneNum().equals("5555553110"));
	}

}
