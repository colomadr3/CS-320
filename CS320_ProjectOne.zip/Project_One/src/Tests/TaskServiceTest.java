package Tests;

import java.util.HashMap;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Project.taskService.Task;
import Project.taskService.TaskService;

public class TaskServiceTest {
	//Create a new hash map
	HashMap<String, Task> taskMap = new HashMap<String,Task>();

	@Test
	//Test AddTask Method
	void TaskServiceAddTest() {
		//Create a new task object
		Task taskObj = new Task("12345", "Wash Socks", "Take of socks and throw them in the washer");
		//Method call to add task to hash map
		TaskService.AddTask(taskMap, taskObj);
		//Assertion to check task object variables in hash map
	    assertAll("Add",()-> assertEquals("Wash Socks",taskMap.get("12345").taskName),
	            		()-> assertEquals("Take of socks and throw them in the washer",taskMap.get("12345").taskDesc));
	}
	
	@Test
	//Test RemoveTask Method
	void TaskServiceRemoveTest() {
		//Create new task objects
		Task taskObj = new Task("789456", "Pet Dog", "He is on the couch. Go pet him");
		Task taskObj2 = new Task("123321", "Flip Table", "You're angry. Flip that table");
		//Method call to add tasks to hash map
		TaskService.AddTask(taskMap, taskObj);
		TaskService.AddTask(taskMap, taskObj2);	
		//Method call to remove task from hash map
		TaskService.RemoveTask(taskMap, "789456");
		//Assertion to check that task was removed
		assertAll("Remove",()-> assertEquals(null,taskMap.get("789456")));

	}
	
	@Test
	//Test methods that update Contact object variables in hash map
	void TaskServiceUpdateTest() {
		//Create new task object
		Task taskObj = new Task("14789", "Backflip", "Do a backflip");
		//Method call to add task to hash map
		TaskService.AddTask(taskMap, taskObj);
		//Method calls to updated Contact object variables in hash map
		TaskService.updateTaskName(taskMap, "14789", "Dance Party");
		TaskService.updateTaskDesc(taskMap, "14789", "Time to get down!");
		//Assertion to check that task object variables were updated
		assertAll("Update",()-> assertEquals("Dance Party",taskMap.get("14789").taskName),
	            		   ()-> assertEquals("Time to get down!",taskMap.get("14789").taskDesc));

	}
	
	@Test
	void testTaskServiceSameID() {
		//Create new Contact objects
		Task taskObj = new Task("99999", "Do the Thing", "You know what it is");
		Task taskObj2 = new Task("99999", "Do the Dew", "Drink a bottle of Mountain Dew");
		
		//Method call to add contacts to hash map
		TaskService.AddTask(taskMap, taskObj);
		//Expect Exception from duplicate IDs
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			TaskService.AddTask(taskMap, taskObj2);
			});
	}
}
