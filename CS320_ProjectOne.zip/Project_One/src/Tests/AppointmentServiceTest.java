package Tests;

import java.util.HashMap;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Calendar;

import Project.appointmentService.Appointment;
import Project.appointmentService.AppointmentService;

public class AppointmentServiceTest {
	//Create a new hash map
	HashMap<String, Appointment> apptMap = new HashMap<String,Appointment>();
	//Calendar starts at 0
	Calendar testDate = Calendar.getInstance();
	Calendar newDate = Calendar.getInstance();

	@Test
	//Test AddAppointment Method;
	void AppointmentServiceAddTest() {
		//Set testDate variable to June 12th
		testDate.set(2023,5,12);
		//Create a new appointment object
		Appointment apptObj = new Appointment("12345", "Fix car", testDate);
		//Method call to add appointment to hash map
		AppointmentService.AddAppointment(apptMap, apptObj);
		//Assertion to check appointment object variables in hash map
	    assertAll("Add",()-> assertEquals("Fix car",apptMap.get("12345").apptDesc),
	            		()-> assertTrue(testDate.getTime().equals(apptObj.getApptDate().getTime())));
	}
	
	@Test
	//Test RemoveAppointmen Method
	void AppointmentServiceRemoveTest() {
		//Set testDate and newDate variables
		testDate.set(2023,10,7);
		newDate.set(2023,7,25);
		//Create new appointment objects
		Appointment apptObj = new Appointment("987654321", "Find Fish", testDate);
		Appointment apptObj2 = new Appointment("123456789", "Fight Clown", testDate);
		//Method call to add appointment to hash map
		AppointmentService.AddAppointment(apptMap, apptObj);
		AppointmentService.AddAppointment(apptMap, apptObj2);
		//Method call to remove appointment from hash map
		AppointmentService.RemoveAppointment(apptMap, "987654321");
		//Assertion to check that appointment was removed
		assertAll("Remove",()-> assertEquals(null,apptMap.get("987654321")));
	}
	
	@Test
	//Test methods that update appointment object variables in hash map
	void AppointmentServiceUpdateTest() {
		//Set testDate and newDate variables
		testDate.set(2023,8,4);
		newDate.set(2023,8,5);
		//Create new appointment object
		Appointment apptObj = new Appointment("456789123", "Dance Recital", testDate);
		//Method call to add appointment to hash map
		AppointmentService.AddAppointment(apptMap, apptObj);
		//Method calls to updated appointment object variables in hash map
		AppointmentService.updateAppointmentDesc(apptMap, "456789123", "Birthday Party");
		AppointmentService.updateAppointmentDate(apptMap, "456789123", newDate);
		//Assertion to check that appointment object variables were updated
		assertAll("Update",()-> assertTrue(newDate.getTime().equals(apptMap.get("456789123").apptDate.getTime())),
	            		   ()-> assertEquals("Birthday Party",apptMap.get("456789123").apptDesc));

	}
	@Test
	//Test RemoveAppointmen Method
	void AppointmentServiceDuplicateID() {
		//Set testDate and newDate variables
		testDate.set(2023,4,31);
		newDate.set(2023,5,14);
		//Create new appointment objects
		Appointment apptObj = new Appointment("22222", "Eat Sandwich", testDate);
		Appointment apptObj2 = new Appointment("22222", "Eat Pizza", newDate);
		//Method call to add appointment to hash map
		AppointmentService.AddAppointment(apptMap, apptObj);
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			AppointmentService.AddAppointment(apptMap, apptObj2);
			});
	}
}
