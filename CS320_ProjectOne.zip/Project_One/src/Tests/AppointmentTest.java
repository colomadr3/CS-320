package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Calendar;

import Project.appointmentService.Appointment;

public class AppointmentTest {
	//Create Calendar variables
	//Calendar starts at 0
	Calendar invalidDate = Calendar.getInstance();
	Calendar inputDate = Calendar.getInstance();
	
	@Test
	//Test Appointment object Constructor
	void testAppointment() {
		//Set test Appointment date
		inputDate.set(2023, 11, 18);
		
		//Create new Appointment object with set arguments
		Appointment apptObj = new Appointment("123456789", "Meet with the guy",inputDate);
		//Assertions to check Appointment object variable
		assertTrue(apptObj.getApptID().equals("123456789"));
		assertTrue(apptObj.getApptDesc().equals("Meet with the guy"));
		assertTrue(inputDate.getTime().equals(apptObj.getApptDate().getTime()));
	}
	
	@Test
	//Tests to check Exception Throws for Appointment object variables - Exceptions expected
	//Tests both requirements for each object arguments
	void testAppointmentObjID() {
		//Set test Appointment date
		inputDate.set(2023, 11, 18);
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Appointment("12345678910", "Do a little Dance", inputDate);
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Appointment(null, "Do a little Dance", inputDate);
			});
	}
	
	@Test
	void testAppointmentObjDesc() {
		//Set test Appointment date
		inputDate.set(2023, 11, 18);
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Appointment("1234", "Remember that time when we went to the store and bought a bunch of snacks...", inputDate);
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Appointment("1234", null, inputDate);
			});
	}
	
	@Test
	void testAppointmentDatePast() {
		//Set invalid Appointment date
		invalidDate.set(2023,0,17);
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Appointment("98765", "Fight with a doctor", invalidDate);
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Appointment("98765", "Fight with a doctor", null);
			});
	}
}
