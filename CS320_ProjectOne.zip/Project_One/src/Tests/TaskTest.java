package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Project.taskService.Task;

public class TaskTest {

	@Test
	//Test Contact object Constructor
	void testTask() {
		//Create new task object with set arguments
		Task taskObj = new Task("123456789", "Clean Floor", "Stop crying and clean the floor");
		//Assertions to check task object variable
		assertTrue(taskObj.getTaskID().equals("123456789"));
		assertTrue(taskObj.getTaskName().equals("Clean Floor"));
		assertTrue(taskObj.getTaskDesc().equals("Stop crying and clean the floor"));
	}
	
	@Test
	//Tests to check Exception Throws for task object variables - Exceptions expected
	//Tests both requirements for each object argument
	void testTaskObjID() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("12345678910", "Eat Cheese", "It's in the fridge in the vegetable crisper");
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task(null, "Eat Cheese", "It's in the fridge in the vegetable crisper");
			});
	}
	
	@Test
	void testTaskObjName() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("98765", "Get all the pillows and build a fort in the backyard", "Be a kid");
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("98765", null, "Be a kid");
			});
	}
	
	@Test
	void testTaskObjDescToLong() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234", "Shower", "Jordan, I am going to need you to shower. The last time you bathed was two weeks ago.");
			});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234", "Shower", null);
			});
	}
}
