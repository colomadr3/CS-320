package Project.contactService;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class ContactService {

	//Method to add contact to hash map - Passing hash map and contact object
	public static void AddContact(HashMap<String, Contact> newContact, Contact contactInfo) {
		//Iterates through hash map to check if passed ID is a duplicate
		Iterator<Entry<String, Contact>> nextContact = newContact.entrySet().iterator();
		while(nextContact.hasNext()){
			Entry<String, Contact> entry = nextContact.next();
			if(contactInfo.getContactID().equals(entry.getKey())) {
				throw new IllegalArgumentException("Invalid Appointment ID");
			}
		}
		//Add Contact object to hash map using contactID as key
		newContact.put(contactInfo.getContactID(), contactInfo);			
	}
	
	//Method to remove contact from hash map - Passing hash map and contact ID
	public static void RemoveContact(HashMap<String, Contact> contactHash, String contactID) {
		//Remove contactInfo from hash map using contactID
		contactHash.remove(contactID);	
	}
	
	//Method to update Contact object's first name of passed contact ID in hash map
	public static void UpdateFName(HashMap<String, Contact> contactHash, String contactID, String fName) {
		//Get Contact object at contact ID
		Contact updatedContact = contactHash.get(contactID);
		//Call setFirstName method to update first name of Contact object
		updatedContact.setFirstName(fName);
		//Replace Contact object at contact Id of hash map with updated Contact object 
		contactHash.replace(contactID,updatedContact);
	}
	
	//Method to update Contact object's last name of passed contact ID in hash map
	public static void UpdateLName(HashMap<String, Contact> contactHash, String contactID, String lName) {
		Contact updatedContact = contactHash.get(contactID);
		updatedContact.setLastName(lName);
		contactHash.replace(contactID,updatedContact);
	}
	
	//Method to update Contact object's phone number of passed contact ID in hash map
	public static void UpdateNumber(HashMap<String, Contact> contactHash, String contactID, String pNumber) {
		Contact updatedContact = contactHash.get(contactID);
		updatedContact.setPhoneNum(pNumber);
		contactHash.replace(contactID,updatedContact);
	}
	
	//Method to update Contact object's address of passed contact ID in hash map
	public static void UpdateAddy(HashMap<String, Contact> contactHash, String contactID, String addy) {
		Contact updatedContact = contactHash.get(contactID);
		updatedContact.setContactAddy(addy);
		contactHash.replace(contactID,updatedContact);
	}

}
