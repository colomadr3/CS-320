package Project.contactService;

public class Contact {
	//Define Contact object variables
	final int MAXID = 10;
	final int MAXNAME = 10;
	final int MAXADDY = 30;
	final int MAXNUM = 10;
	public String firstName;
	public String lastName;
	private String contactID;
	public String contactAddy;
	public String phoneNum;

	//Constructor passing all Contact Class variable arguments
	public Contact(String firstName, String lastName, String contactID, String contactAddy, String phoneNum) {
		
		//Contact ID requirement
		if(contactID == null || contactID.length() > MAXID) {
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		
		//Call setters to assign class arguments 
		this.contactID = contactID;
		setFirstName(firstName);
		setLastName(lastName);
		setContactAddy(contactAddy);
		setPhoneNum(phoneNum);
		
		return;
	}
	
	//First Name Setter
	protected void setFirstName(String firstName) {
		if(firstName == null || firstName.length() > MAXNAME) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		this.firstName = firstName;
		return;
	}
	
	//Last Name Setter
	protected void setLastName(String lastName) {
		if(lastName == null || lastName.length() > MAXNAME) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		this.lastName = lastName;
	}
	
	//Address Setter
	protected void setContactAddy(String contactAddy) {
		if(contactAddy == null || contactAddy.length() > MAXADDY) {
			throw new IllegalArgumentException("Invalid Address");
		}
		this.contactAddy = contactAddy;
	}
	
	//Phone Number Setter
	protected void setPhoneNum(String phoneNum) {
		if(phoneNum == null || phoneNum.length() != MAXNUM) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		this.phoneNum = phoneNum;
	}
	
	//First Name Getter
	public String getFirstName() {
		return firstName;
	}
	
	//Last Name Getter
	public String getLastName() {
		return lastName;
	}
	
	//Contact ID Getter
	public String getContactID() {
		return contactID;
	}
	
	//Address Getter
	public String getContactAddy() {
		return contactAddy;
	}
	
	//Phone Number Getter
	public String getPhoneNum() {
		return phoneNum;
	}
}
