package Project.appointmentService;

import java.util.*;
import java.util.Map.Entry;

public class AppointmentService {

	//Method to add Appointment to hash map - Pass hash map and Appointment object
	public static void AddAppointment(HashMap<String, Appointment> apptHash, Appointment apptInfo) {
		//Iterates through hash map to check if passed ID is a duplicate
		Iterator<Entry<String, Appointment>> nextAppt = apptHash.entrySet().iterator();
		while(nextAppt.hasNext()){
			Entry<String, Appointment> entry = nextAppt.next();
			if(apptInfo.getApptID().equals(entry.getKey())) {
				throw new IllegalArgumentException("Invalid Appointment ID");
			}
		}
		//Add appointment object to hash map using apptID as key
		apptHash.put(apptInfo.getApptID(), apptInfo);			
	}
	
	//Method to remove appointment from hash map - Pass hash map and appointment ID
	public static void RemoveAppointment(HashMap<String, Appointment> apptHash, String apptID) {
		//Remove appointment object from hash map using apptID
		apptHash.remove(apptID);	
	}
	
	//Method to update appointment object's date - pass appointment ID and hash map
	public static void updateAppointmentDate(HashMap<String, Appointment> apptHash, String apptID, Calendar apptDate) {
		//Get appointment object from hash map with appointment ID
		Appointment updatedAppt = apptHash.get(apptID);
		//Call setApptDate method to update the date of appoint object
		updatedAppt.setApptDate(apptDate);
		//Replace appointment object at appointment Id on hash map with updated appointment object 
		apptHash.replace(apptID,updatedAppt);
	}
	
	//Method to update appointment object's description - pass appointment ID and hash map
	public static void updateAppointmentDesc(HashMap<String, Appointment> apptHash, String apptID, String apptDesc) {
		Appointment updatedAppt = apptHash.get(apptID);
		updatedAppt.setApptDesc(apptDesc);
		apptHash.replace(apptID,updatedAppt);
	}
}
