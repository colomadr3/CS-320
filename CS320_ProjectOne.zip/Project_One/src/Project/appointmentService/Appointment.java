package Project.appointmentService;

import java.util.Calendar;

public class Appointment {
	//Define Appointment object variables
	final int MAXID = 10;
	final Calendar TODAY = Calendar.getInstance();
	final int MAXDESC = 50;
	private String apptID;
	public Calendar apptDate;
	public String apptDesc;

	//Constructor passing all Appointment Class variable arguments
	public Appointment(String apptID, String apptDesc, Calendar apptDate) {
		
		//If statements to validate arguments requirements
		//Appointment ID requirements
		if(apptID == null || apptID.length() > MAXID) {
			throw new IllegalArgumentException("Invalid Appointment ID");
		}
		
		//Call setters and assign object arguments 
		this.apptID = apptID;
		setApptDate(apptDate);
		setApptDesc(apptDesc);
		return;
	}
	
	//Appointment Date Setter
	protected void setApptDate(Calendar apptDate) {
		if(apptDate == null || apptDate.getTime().before(TODAY.getTime())) {
			throw new IllegalArgumentException("Invalid Appointment Date");
		}
		this.apptDate = apptDate;
	}
	
	//Appointment Description Setter
	protected void setApptDesc(String apptDesc) {
		if(apptDesc == null || apptDesc.length() > MAXDESC) {
			throw new IllegalArgumentException("Invalid Appointment Description");
		}
		this.apptDesc = apptDesc;
	}
	
	//Appointment ID Getter
	public String getApptID() {
		return apptID;
	}
	
	//Appointment Date Getter
	public Calendar getApptDate() {
		return apptDate;
	}
	
	//Appointment description Getter
	public String getApptDesc() {
		return apptDesc;
	}

}
