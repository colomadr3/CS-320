package Project.taskService;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class TaskService {

	//Method to add task to hash map - Pass hash map and task object
	public static void AddTask(HashMap<String, Task> taskHash, Task taskInfo) {
		//Iterate through hashmap to check if a passed ID is a duplicate
		Iterator<Entry<String, Task>> nextTask = taskHash.entrySet().iterator();
		while(nextTask.hasNext()){
			Entry<String, Task> entry = nextTask.next();
			if(taskInfo.getTaskID().equals(entry.getKey())) {
				throw new IllegalArgumentException("Invalid Appointment ID");
			}
		}
		//Add task object to hash map using taskID as key
		taskHash.put(taskInfo.getTaskID(), taskInfo);			
	}
	
	//Method to remove task from hash map - Pass hash map and task ID
	public static void RemoveTask(HashMap<String, Task> taskHash, String taskID) {
		//Remove task object from hash map using taskID
		taskHash.remove(taskID);	
	}
	
	//Method to update task object's name - pass task ID and hash map
	public static void updateTaskName(HashMap<String, Task> taskHash, String taskID, String TName) {
		//Get task object from hash map with task ID
		Task updatedTask = taskHash.get(taskID);
		//Call setTaskName method to update the name of task object
		updatedTask.setTaskName(TName);
		//Replace task object at task Id on hash map with updated task object 
		taskHash.replace(taskID,updatedTask);
	}
	
	//Method to update task object's description - pass task ID and hash map
	public static void updateTaskDesc(HashMap<String, Task> taskHash, String taskID, String TDesc) {
		Task updatedTask = taskHash.get(taskID);
		updatedTask.setTaskDesc(TDesc);
		taskHash.replace(taskID,updatedTask);
	}
}
