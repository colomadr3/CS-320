package Project.taskService;

public class Task {
	//Define Contact object variables
	final int MAXID = 10;
	final int MAXNAME = 20;
	final int MAXDESC = 50;
	private String taskID;
	public String taskName;
	public String taskDesc;

	//Constructor passing all Contact Class variable arguments
	public Task(String taskID, String taskName, String taskDesc) {
		
		//If statement to validate argument requirements
		//Task ID requirements
		if(taskID == null || taskID.length() > MAXID) {
			throw new IllegalArgumentException("Invalid Task ID");
		}
		
		//Call setters and assigns object arguments
		this.taskID = taskID;
		setTaskName(taskName);
		setTaskDesc(taskDesc);
		return;
	}
	
	//Task Name Setter
	protected void setTaskName(String taskName) {
		if(taskName == null || taskName.length() > MAXNAME) {
			throw new IllegalArgumentException("Invalid Task Name");
		}
		this.taskName = taskName;
	}
	
	//Task Description Setter
	protected void setTaskDesc(String taskDesc) {
		if(taskDesc == null || taskDesc.length() > MAXDESC) {
			throw new IllegalArgumentException("Invalid Task Description");
		}
		this.taskDesc = taskDesc;
	}
	
	//First task ID Getter
	public String getTaskID() {
		return taskID;
	}
	
	//Last task name Getter
	public String getTaskName() {
		return taskName;
	}
	
	//Contact task description Getter
	public String getTaskDesc() {
		return taskDesc;
	}

}
